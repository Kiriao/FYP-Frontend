// vertex.ts (stable: REST for embed + search; SDK for upsert)
import { GoogleAuth } from "google-auth-library";
import { protos, IndexServiceClient } from "@google-cloud/aiplatform";

const PROJECT_ID = process.env.PROJECT_ID!;
const LOCATION = process.env.LOCATION || "asia-southeast1";
const INDEX_RESOURCE = process.env.INDEX_RESOURCE!;       // .../indexes/<ID>
const INDEX_ENDPOINT = process.env.INDEX_ENDPOINT!;       // .../indexEndpoints/<ID>
const DEPLOYED_INDEX_ID = process.env.DEPLOYED_INDEX_ID!; // "recs-deployed"
const EMBEDDING_MODEL = process.env.EMBEDDING_MODEL || "text-embedding-004";

const indexClient = new IndexServiceClient();

/** ---------- Embeddings via REST (works with ADC) ---------- */
export async function embedText(text: string): Promise<number[]> {
  const auth = new GoogleAuth({ scopes: ["https://www.googleapis.com/auth/cloud-platform"] });
  const client = await auth.getClient();

  const url = `https://${LOCATION}-aiplatform.googleapis.com/v1/projects/${PROJECT_ID}/locations/${LOCATION}/publishers/google/models/${EMBEDDING_MODEL}:embedContent`;
  const body = { content: { parts: [{ text }] } };

  const resp = await client.request<{ embeddings?: { values?: number[] } | { values: number[] }[] }>({
    url, method: "POST", data: body,
  });

  const e = resp.data.embeddings as any;
  const values = e?.values || e?.[0]?.values || [];
  if (!Array.isArray(values) || values.length === 0) throw new Error("Empty embedding response");
  return values as number[];
}

export type Restricts = Record<string, string | number | boolean>;

/** helper: convert key/value filters into ME restricts */
function toRestricts(filters: Restricts = {}): protos.google.cloud.aiplatform.v1.IndexDatapoint.IRestriction[] {
  return Object.entries(filters).map(([k, v]) => ({
    namespace: String(k),
    allowList: [String(v)],
  }));
}

/** ---------- Upsert via SDK (ensure numericRestricts present) ---------- */
export async function upsertVectors(
  payload: Array<{ id: string; vector: number[]; restricts?: Restricts }>
) {
  const datapoints: protos.google.cloud.aiplatform.v1.IIndexDatapoint[] = payload.map(p => ({
    datapointId: p.id,
    featureVector: p.vector as number[],
    restricts: toRestricts(p.restricts),
    // TS typing expects this field to exist; leave empty if you don't use numeric filters
    numericRestricts: [],
  }));

  await indexClient.upsertDatapoints({
    index: INDEX_RESOURCE,
    datapoints,
  });
}

/** ---------- Search via REST (indexEndpoints:findNeighbors) ---------- */
export async function findNeighbors(
  queryVector: number[],
  filters: Restricts = {},
  neighborCount = 20
): Promise<Array<{ id: string; distance: number }>> {
  const auth = new GoogleAuth({ scopes: ["https://www.googleapis.com/auth/cloud-platform"] });
  const client = await auth.getClient();

  // POST https://.../indexEndpoints/{id}:findNeighbors
  const url = `https://${LOCATION}-aiplatform.googleapis.com/v1/${INDEX_ENDPOINT}:findNeighbors`;

  const body = {
    deployedIndexId: DEPLOYED_INDEX_ID,
    queries: [{
      datapoint: { featureVector: queryVector },
      neighborCount,
      restricts: toRestricts(filters),
    }],
  };

  type Neighbor = { datapoint?: { datapointId?: string }, distance?: number };
  const resp = await client.request<{ nearestNeighbors?: { neighbors?: Neighbor[] }[] }>({
    url, method: "POST", data: body,
  });

  const nn = (resp.data.nearestNeighbors?.[0]?.neighbors || []);
  return nn.map(n => ({
    id: String(n.datapoint?.datapointId ?? ""),
    distance: Number(n.distance ?? 0),
  }));
}
