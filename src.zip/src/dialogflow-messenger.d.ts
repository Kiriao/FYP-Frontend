// src/dialogflow-messenger.d.ts

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "df-messenger": any;
      "df-messenger-chat-bubble": any;
    }
  }
}

export {};
