export const dynamic = "force-dynamic"; // Disable static pre-rendering
import CheckoutClient from "./CheckoutClient";

export default function CheckoutPage() {
  return <CheckoutClient />;
}
