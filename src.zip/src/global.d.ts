/// <reference path="../dialogflow-messenger.d.ts" />
cmd