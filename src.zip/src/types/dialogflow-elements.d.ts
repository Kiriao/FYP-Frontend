declare namespace JSX {
  interface IntrinsicElements {
    'df-messenger': any;
    'df-messenger-chat-bubble': any;
  }
}
